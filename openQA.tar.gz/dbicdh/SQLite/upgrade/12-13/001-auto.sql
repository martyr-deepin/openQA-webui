-- Convert schema '/home/maxlin/src_orig/my_oqa/openQA/script/../dbicdh/_source/deploy/12/001-auto.yml' to '/home/maxlin/src_orig/my_oqa/openQA/script/../dbicdh/_source/deploy/13/001-auto.yml':;

;
-- No differences found;

